const fs = require('fs');
const path = require('path');
const express = require('express');
const cors = require("cors");
const app = express();
const port = 3333;
//const PORT = process.env.PORT || 3333;

//app.use(cors())

app.use(
    cors({
        origin: "*",
    }
    )
);


app.get('/', function(req, res) {
    res.send('Connected to API')
})



app.get("/", cors(), async(req, res) => {
    res.send("This is working")
})

app.listen(port, () => {
    console.log(`Ecouter le port a http://localhost:${port}`)
})

module.exports = app;

/*
app.post("/post_name", async(req, res) => {
    let{name}=req.body
    console.log(name)
})
*/

/*



/*
const LIVRES =[
    {
        id: 1,
        titre: "Les heures",
        auteur:"Michael Cunningham",
    },

    {
        id: 2,
        titre: "L ange du Nord",
        auteur: "Kathy Reichs",
    },

    {
        id:3,
        titre: "Operation Sweet Tooth",
        auteur: "Ian McEwan",
    }
]
*/


//Création de document txt dans Bibliotheque
/*for (let livre of LIVRES ) {
    fs.appendFile(`./Bibliotheque/${livre.titre.split(' ').join('_')}.txt`, JSON.stringify(livre), (err)=> {
        if (err){
            console.log(err)
        }
    })
}
*/

//Lecture de Texte.txt
/*
fs.readFile('./Texte.txt', 'utf-8', (err, data)=> {
    if(err) {
        console.log(err)
    }
    console.log(data)
})
*/

//Suppression de Test.txt asynchrone
/*fs.unlink('./Test.txt', (err)=>{
    if(err){
        return console.log(err)
    }
})
*/

//Suppression de Test.txt synchrone
/*try {
    fs.unlinkSync('./Test.txt')

    } catch(err) {
    console.error(err)
    }
*/


/*
fs.mkdir(path.join('./Bibliotheque', 'test'), (err)=>{
    if(err){
        return console.error(err)
    }
})
*/

