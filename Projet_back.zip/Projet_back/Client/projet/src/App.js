import './App.css';
import React, {useEffect} from 'react';
import axios from 'axios';


export default function App() {
  useEffect(() => {
    getApi()  
  }, [] )

  const getApi = () => {
    const response = axios.get('http://localhost:3333')
    console.log(response)
  }
}